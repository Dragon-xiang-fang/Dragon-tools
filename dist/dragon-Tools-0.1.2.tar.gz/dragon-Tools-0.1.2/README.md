# 自己制作的常用工具 by DragonXiang
### 实现一些常用的功能
#### 首先需要构建项目: py -m build
### 使用这个命令实现包上传到PyPI: twine upload dist/*
### 账号: __token__
#### 详情可以上这个网址查看: https://packaging.python.org/en/latest/tutorials/packaging-projects/