from dragonTools.pdf_to_image import py_PDF_to_Image as PDF_to_Image
from dragonTools.pdf_get_image import get_image

'''
    @fun PDF_to_Image
    可以将PDF文件转成图片

    @fun get_image
    可以从PDF文件中提取多个图片
'''
